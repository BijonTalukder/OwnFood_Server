const mongoose = require("mongoose");
const GetSingleOrderStatusService = async (request, Model) => {
  try {
    let id = mongoose.Types.ObjectId(request.params.id);
    let data = await Model.aggregate([
      {
        $match: { _id: id },
      },
      {
        $project: {
          orderStatusTitle: 1,
          orderBy: 1,
          status: 1,
        },
      },
    ]);
    return { status: "Success", data: data };
  } catch (e) {
    return { status: "Fail", data: e };
  }
};

module.exports = GetSingleOrderStatusService;
